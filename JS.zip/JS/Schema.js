const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    UserID: { type: Number, unique: true },
    UserName: { type: String, maxlength: 100, required: true },
    UserPassword: { type: String, maxlength: 300, required: true },
    EmailAddress: { type: String, maxlength: 300, required: true },
    PhoneNumber: { type: String, maxlength: 50 },
    IsAdmin: { type: Boolean, default: false }
}, {
    timestamps: true
});

const instituteSchema = new mongoose.Schema({
    InstituteID: { type: Number, unique: true },
    InstituteName: { type: String, maxlength: 100, required: true },
    InsituteImage: { type: String, maxlength: 300 },
    InsituteDescription: { type: String, maxlength: 1000 },
    InsituteCoOrdinatorID: { type: Number, required: true },
    ModifiedBy: { type: Number }
}, {
    timestamps: {
        createdAt: "CreatedAt",
        updatedAt: "ModifiedAt"
    }
});

const departmentSchema = new mongoose.Schema({
    DepartmentID: { type: Number, unique: true },
    DepartmentName: { type: String, maxlength: 100, required: true },
    DepartmentImage: { type: String, maxlength: 300 },
    DepartmentDescription: { type: String, maxlength: 1000 },
    InstituteID: { type: Number, required: true },
    DepartmentCoOrdinatorID: { type: Number },
    ModifiedBy: { type: Number }
}, {
    timestamps: {
        createdAt: "CreatedAt",
        updatedAt: "ModifiedAt"
    }
});

const eventSchema = new mongoose.Schema({
    EventID: { type: Number, unique: true },
    EventName: { type: String, maxlength: 100, required: true },
    EventTagline: { type: String, maxlength: 300 },
    EventImage: { type: String, maxlength: 300 },
    EventDescription: { type: String, maxlength: 1000 },
    GroupMinParticipants: { type: Number },
    GroupMaxParticipants: { type: Number },
    EventFees: { type: Number },
    EventFirstPrice: { type: String, maxlength: 300 },
    EventSecondPrice: { type: String, maxlength: 300 },
    EventThirdPrice: { type: String, maxlength: 300 },
    DepartmentID: { type: Number, required: true },
    EventCoOrdinatorID: { type: Number },
    EventMainStudentCoOrdinatorName: { type: String, maxlength: 100 },
    EventMainStudentCoOrdinatorPhone: { type: String, maxlength: 100 },
    EventMainStudentCoOrdinatorEmail: { type: String, maxlength: 300 },
    EventLocation: { type: String, maxlength: 100 },
    MaxGroupsAllowed: { type: Number },
    ModifiedBy: { type: Number }
}, {
    timestamps: {
        createdAt: "CreatedAt",
        updatedAt: "ModifiedAt"
    }
});

const groupSchema = new mongoose.Schema({
    GroupID: { type: Number, unique: true },
    GroupName: { type: String, maxlength: 100, required: true },
    EventID: { type: Number, required: true },
    IsPaymentDone: { type: Boolean, default: false },
    IsPresent: { type: Boolean, default: false },
    ModifiedBy: { type: Number }
}, {
    timestamps: {
        createdAt: "CreatedAt",
        updatedAt: "ModifiedAt"
    }
});

const participantSchema = new mongoose.Schema({
    ParticipantID: { type: Number, unique: true },
    ParticipantName: { type: String, maxlength: 100, required: true },
    ParticipantEnrollmentNumber: { type: String, maxlength: 100 },
    ParticipantInsituteName: { type: String, maxlength: 300 },
    ParticipantCIty: { type: String, maxlength: 300 },
    ParticipantMobile: { type: String, maxlength: 100 },
    ParticipantEmail: { type: String, maxlength: 300 },
    IsGroupLeader: { type: Boolean, default: false },
    GroupID: { type: Number, required: true },
    ModifiedBy: { type: Number }
}, {
    timestamps: {
        createdAt: "CreatedAt",
        updatedAt: "ModifiedAt"
    }
});

const eventWiseWinnerSchema = new mongoose.Schema({
    EventWiseWinnerID: { type: Number, unique: true },
    EventID: { type: Number, required: true },
    GroupID: { type: Number, required: true },
    Sequence: { type: Number },
    ModifiedBy: { type: Number }
}, {
    timestamps: {
        createdAt: "CreatedAt",
        updatedAt: "ModifiedAt"
    }
});

module.exports = {
    Users: mongoose.model("Users", userSchema),
    Institutes: mongoose.model("Institutes", instituteSchema),
    Departments: mongoose.model("Departments", departmentSchema),
    Events: mongoose.model("Events", eventSchema),
    Groups: mongoose.model("Groups", groupSchema),
    Participants: mongoose.model("Participants", participantSchema),
    EventWiseWinners: mongoose.model("EventWiseWinners", eventWiseWinnerSchema)
};
