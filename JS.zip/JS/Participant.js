// Participant APIs: o GET /api/groups/:groupId/participants o POST /api/groups/:groupId/participants 
//  PUT /api/participants/:id o DELETE /api/participants/:id

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const { Participants } = require('./Schema.js');


mongoose.connect("")
.then(()=>console.log("Database connected successfully"))
.catch((err)=>console.log(err))

app.get("/api/groups/:groupId/participants" , async(req,res)=>{
    try{
        const data = await Participants.find({GroupID : Number(req.params.id)});
        if(data.length === 0) return res.status(404).json({message : "No Data Found"});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
})

app.post("/api/groups/:groupId/participants" , async(req,res)=>{
    try{
        const data = await Participants({...req.body , GroupID:req.params.groupId});
        await data.save();
        res.status(201).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
})

app.put("/api/participants/:id" , async(req,res)=>{
    try{
        const data = await Participants.findOneAndUpdate({ParticipantID : Number(req.params.id)} , req.body , {new : true});
        if(!data) res.status(404).json({message : "No Data Found with "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.delete("/api/participants/:id" , async(req,res)=>{
    try{
        const data = await Participants.findOneAndUpdate({ParticipantID : Number(req.params.id)});
        if(!data) res.status(404).json({messagee : "No Data Found With "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.listen(3000 , ()=>console.log("Server started running on port 3000"));
