// Week 5 – Institutes & Departments Backend APIs 
// Topics 
//  RESTful API design 
//  Relations: Institute → Departments 
//  Assigning coordinators (UserID as foreign key) 
// Student Tasks 
//  Implement Institute APIs: o GET /api/institutes o GET /api/institutes/:id 
// o POST /api/institutes (Admin only) o PUT /api/institutes/:id o DELETE /api/institutes/:id 
//  Implement Department APIs: o GET /api/departments o GET /api/institutes/:id/departments o POST /api/departments o PUT /api/departments/:id o DELETE /api/departments/:id 

const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.use(express.json());

const { Departments } = require('./Schema.js');


mongoose.connect("mongodb://localhost:27017/Frolic")
.then(()=>console.log("Database connected successfully"))
.catch((err)=>console.log(err))


// DepartmentID
app.get("/api/departments" , async(req,res)=>{
    try{
        const data = await Departments.find();
        if(data.length === 0) return res.status(404).json({message: "No departments found "});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.get("/api/institutes/:id/departments" , async(req,res)=>{
    try{
        const data = await Departments.find({InstituteID : Number(req.params.id)});
    if (data.length === 0) {
        return res.status(404).json({
            message: "No departments found for institute " + req.params.id
        });
    }
    res.status(200).json(data)
    }   
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.post("/api/departments" , async(req,res)=>{
    try{
        const data = new Departments(req.body);
        await data.save();
        res.status(201).json({message : "Department Added", data});
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.put("/api/departments/:id" , async(req,res)=>{
    try{
        const data = await Departments.findOneAndUpdate({DepartmentID : Number(req.params.id)} , req.body , { new: true })
        if(!data) return res.status(404).json({message : "No department found with "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.delete("/api/departments/:id" , async(req,res)=>{
    try{
        const data = await Departments.findOneAndDelete({DepartmentID : Number(req.params.id)});
        if(!data) return res.status(404).json({message : "No department found with "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.listen(3000,()=>console.log("Server started on port 3000"));
