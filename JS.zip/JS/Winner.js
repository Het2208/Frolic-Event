// Winner APIs: o GET /api/events/:eventId/winners 
// o POST /api/events/:eventId/winners (Admin / EventCoordinator) o PUT /api/winners/:id o DELETE /api/winners/:id

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const { Winners } = require('./Schema.js');

mongoose.connect("")
.then(()=>console.log("Database connected successfully"))
.catch((err)=>console.log(err))

app.get("/api/events/:eventId/winners" , async(req,res)=>{
    try{
        const data = await Winners.find({EventID : req.params.eventId});
        if(data.length === 0) return res.status(404).json({message : "No Data Found"});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
})

app.post("/api/events/:eventId/winners" , async(req,res)=>{
    try{
        const data = await Winners({...req.body , EventID:req.params.EventId});
        data.save();
        res.status(201).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.put("/api/winners/:id" , async(req,res)=>{
    try{
        const data = await Winners.findOneAndUpdate({WinnerID : Number(req.params.id)} , req.body , {new : true});
        if(!data) res.status(404).json({message : "No Data Found With "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.delete("/api/winners/:id" , async(req,res)=>{
    try{
        const data = await Winners.findOneAndDelete({WinnerID : Number(req.params.id)});
        if(!data) return res.status(404).json({message : "No Data Found With "+req.params.id});
        res.status(200).json(data); 
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.listen(3000 , ()=>console.log("Server started on port 3000"));