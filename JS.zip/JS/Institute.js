const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());

const { Institutes } = require('./Schema.js');

mongoose.connect("mongodb://localhost:27017/Frolic")
.then(()=>console.log("Database connected successfully"))
.catch((err)=>console.log(err));

app.get("/api/institutes" , async(req,res)=>{
    try{
        const data = await Institutes.find();
        if(data.length === 0) return res.status(404).json({ message: "No Institute Found" });
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.get("/api/institutes/:id" , async(req,res)=>{
    try{
        const data = await Institutes.findOne({InstituteID : Number(req.params.id)});
        if(!data) return res.status(404).json({ message: `No institute found with ID ${req.params.id}` });
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.post("/api/institutes" , async(req,res)=>{
    try{
        const exists = await Institutes.findOne({ InstituteName: req.body.InstituteName });
        if (exists) return res.status(400).json({ message: "Institute already exists" });

        const data = new Institutes(req.body);
        await data.save();
        res.status(201).json({message:"Institute Added" , data});
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.put("/api/institutes/:id" , async(req,res)=>{
    try{
        const data = await Institutes.findOneAndUpdate({InstituteID : Number(req.params.id)} , req.body , { new: true });
        if(!data) return res.status(404).json({message : "No Institue Found with "+ req.params.id});
        res.status(200).json({ message: "Institute Updated", data });
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.delete("/api/institutes/:id" , async(req,res)=>{
    try{
        const data = await Institutes.findOneAndDelete({InstituteID : Number(req.params.id)});
        if(!data) return res.status(404).json({message : "No Institue Found with "+ req.params.id});
        res.status(200).json({ message: "Institute Deleted", data });
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.listen(3000 , ()=>console.log("Server is running on port 3000"));