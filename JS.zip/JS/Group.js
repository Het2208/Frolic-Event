// Group APIs: o GET /api/events/:eventId/groups o POST /api/events/:eventId/groups 
// o PUT /api/groups/:id (update name, isPaymentDone, isPresent) o DELETE /api/groups/:id

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const { Groups } = require('./Schema.js');


mongoose.connect("")
.then(()=>console.log("Database connected successfully"))
.catch((err)=>console.log(err));

app.get("/api/events/:eventId/groups" , async(req,res)=>{
    try{
        const data = Groups.find({EventID : Number(req.params.eventId)});
        if(data.length === 0) return res.status(404).json({message : "No Group Found With Event ID "+req.params.eventId});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.post("/api/events/:eventId/groups" , async(req,res)=>{
    try{
        const data = new Groups({...req.body,EventID:req.params.eventId});
        await data.save();
        res.status(201).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
})

app.put("/api/groups/:id" , async(req,res)=>{
    try{
        const data = await Groups.findOneAndUpdate({GroupID : Number(req.params.id)} , req.body , {new : true});
        if(!data) res.status(404).json({message : "No Data Found With "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
})

app.delete("/api/groups/:id" , async(req,res)=>{
    try{
        const data = await Groups.findOneAndDelete({GroupID : Number(req.params.id)});
        if(!data) res.status(404).json({message : "No Data Found With "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.listen(3000 , ()=>console.log("Server started running on port 3000"));