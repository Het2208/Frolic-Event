// Student Tasks 
//  Implement Event APIs: o GET /api/events o GET /api/events/:id o GET /api/departments/:id/events 
// o POST /api/events (Admin / DepartmentCoordinator) o PUT /api/events/:id o DELETE /api/events/:id 
//  Add validations: o groupMinParticipants <= groupMaxParticipants o maxGroupsAllowed > 0

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const {Events} = require('./Schema.js');

mongoose.connect("mongodb://localhost:27017/Frolic")
.then(()=>console.log("Database connect successfully"))
.catch((err)=>console.log(err));

// EventID
app.get("/api/events" , async(req,res)=>{
    try{
        const data = await Events.find();
        if(data.length === 0) return res.status(404).json({message : "No Events Found"});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.get("/api/events/:id" , async(req,res)=>{
    try{
        const data = await Events.findOne({EventID : Number(req.params.id)});
        if(!data) return res.status(404).json({message : "No Event Found With "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
})

app.get("/api/departments/:id/events" , async(req,res)=>{
    try{
        const data = await Events.find({DepartmentID : Number(req.params.id)});
        if(data.length === 0) return res.status(404).json({message : "No Event Found for Department "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.post("/api/events" , async(req,res)=>{
    try{
        const data = new Events(req.body);
        await data.save();
        res.status(201).json({message : "Data Added"});
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.put("/api/events/:id" , async(req,res)=>{
    try{
        const data = await Events.findOneAndUpdate({EventID : Number(req.params.id)} , req.body , {new : true});
        if(!data) return res.status(404).json({message : "No Event Found With "+req.params.id});
        res.status(200).json(data);
    }
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.delete("/api/events/:id" , async(req,res)=>{
    try{
        const data = await Events.findOneAndDelete({EventID : Number(req.params.id)});
        if(!data) return res.status(404).json({message : "No Event found With "+req.params.id});
        res.status(200).json(data);
    }   
    catch(err){
        res.status(500).json({error : err.message});
    }
});

app.listen(3000 , ()=>console.log("Server started running on port 3000"));
